const { ActivityType } = require("discord.js");

const statuses = [ "dnd"];

function startPresenceRotation(client) {
  let statusIndex = 0;
  let timer;

  const updatePresence = () => {
    try {
      client.user.setPresence({
        status: statuses[statusIndex],
        activities: [{ name: "Watching AI Chats", type: ActivityType.Watching }],
      });
      statusIndex = (statusIndex + 1) % statuses.length;
    } catch (error) {
      console.error("Could not update bot presence:", error);
      clearInterval(timer);
    }
  };

  updatePresence();
  timer = setInterval(updatePresence, 10_000);
  return timer;
}

module.exports = startPresenceRotation;
