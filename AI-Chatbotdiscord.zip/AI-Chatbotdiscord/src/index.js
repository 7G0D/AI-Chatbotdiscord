require("dotenv").config();

const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  Client,
  GatewayIntentBits,
  MessageFlags,
  PermissionFlagsBits,
} = require("discord.js");
const startPresenceRotation = require("../functions/presense");

const requiredVariables = [
  "DISCORD_TOKEN",
  "CHAT_COMMAND_CHANNEL_ID",
  "CHAT_CATEGORY_ID",
  "GEMINI_API_KEY",
];
const missingVariables = requiredVariables.filter(
  (name) => !process.env[name],
);

if (missingVariables.length > 0) {
  throw new Error(`Missing required environment variables: ${missingVariables.join(", ")}`);
}

const model = process.env.GEMINI_MODEL || "gemini-flash-lite-latest";
const geminiTimeoutMs = Number(process.env.GEMINI_TIMEOUT_MS || 120_000);
if (!Number.isFinite(geminiTimeoutMs) || geminiTimeoutMs <= 0) {
  throw new Error("GEMINI_TIMEOUT_MS must be a positive number of milliseconds.");
}

const geminiEndpoint =
  "https://generativelanguage.googleapis.com/v1beta/interactions";
const maxGeminiAttempts = 3;
const maxHistoryItems = 20;

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

const conversations = new Map();
const channelQueues = new Map();
const closeButtonIds = new Set([
  "close_private_chat",
  "confirm_close_private_chat",
  "cancel_close_private_chat",
]);

function getPrivateChatOwner(channel) {
  const match = /^private-ai-owner:(\d+)$/.exec(channel.topic || "");
  return match?.[1] ?? null;
}

function channelNameFor(displayName) {
  const channelName = displayName
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9-]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 100)
    .replace(/-+$/g, "");

  return channelName || "chat";
}

async function generateReply(contents, onRetry) {
  let response;
  for (let attempt = 1; attempt <= maxGeminiAttempts; attempt += 1) {
    try {
      response = await fetch(geminiEndpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": process.env.GEMINI_API_KEY,
        },
        body: JSON.stringify({
          model,
          input: contents
            .map(({ role, parts }) => {
              const speaker = role === "model" ? "Assistant" : "User";
              const text = parts.map((part) => part.text || "").join("");
              return `${speaker}: ${text}`;
            })
            .join("\n\n"),
          store: false,
        }),
        signal: AbortSignal.timeout(geminiTimeoutMs),
      });
    } catch (error) {
      if (error.name === "TimeoutError") {
        throw new Error(
          `Gemini did not respond within ${geminiTimeoutMs} ms. ` +
          "Check the network and Gemini API status, or increase GEMINI_TIMEOUT_MS.",
          { cause: error },
        );
      }
      throw error;
    }

    if (response.ok || response.status < 500 && response.status !== 429) {
      break;
    }

    const details = await response.text();
    if (attempt === maxGeminiAttempts) {
      throw new Error(`Gemini API returned ${response.status}: ${details}`);
    }

    const retryAfter = Number(response.headers.get("retry-after"));
    const delayMs = Number.isFinite(retryAfter) && retryAfter > 0
      ? Math.min(retryAfter * 1000, 30_000)
      : 1_000 * (2 ** (attempt - 1));
    const retryMessage =
      `Gemini returned ${response.status}; retrying in ${delayMs / 1000} seconds ` +
      `(attempt ${attempt + 1}/${maxGeminiAttempts}).`;
    console.warn(retryMessage);
    await onRetry?.(retryMessage);
    await new Promise((resolve) => setTimeout(resolve, delayMs));
  }

  if (!response.ok) {
    const details = await response.text();
    throw new Error(`Gemini API returned ${response.status}: ${details}`);
  }

  const data = await response.json();
  const text = (
    typeof data.output_text === "string"
      ? data.output_text
      : data.steps
        ?.filter((step) => step.type === "model_output")
        .flatMap((step) => step.content || [])
        .filter((part) => part.type === "text")
        .map((part) => part.text || "")
        .join("") || ""
  ).trim();

  if (!text) {
    throw new Error("Gemini returned no text for this message.");
  }

  return text;
}

async function sendReply(channel, text) {
  const chunkSize = 1900;
  for (let offset = 0; offset < text.length; offset += chunkSize) {
    await channel.send({
      content: text.slice(offset, offset + chunkSize),
      allowedMentions: { parse: [] },
    });
  }
}

async function handlePrivateChatMessage(message) {
  const history = conversations.get(message.channel.id) || [];
  const contents = [
    ...history,
    { role: "user", parts: [{ text: message.content }] },
  ];
  const statusMessage = await message.reply({
    content: "Thinking...",
    allowedMentions: { parse: [] },
  });

  try {
    const reply = await generateReply(contents, async (status) => {
      try {
        await statusMessage.edit({
          content: status,
          allowedMentions: { parse: [] },
        });
      } catch (error) {
        console.warn(
          `Could not update AI status in channel ${message.channel.id}:`,
          error,
        );
      }
    });

    conversations.set(
      message.channel.id,
      [
        ...contents,
        { role: "model", parts: [{ text: reply }] },
      ].slice(-maxHistoryItems),
    );
    await sendReply(message.channel, reply);
    try {
      await statusMessage.delete();
    } catch (error) {
      console.warn(
        `Could not remove AI status in channel ${message.channel.id}:`,
        error,
      );
    }
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    try {
      await statusMessage.edit({
        content: `AI request failed: ${errorMessage}`.slice(0, 1900),
        allowedMentions: { parse: [] },
      });
    } catch (statusError) {
      console.warn(
        `Could not report AI failure in channel ${message.channel.id}:`,
        statusError,
      );
    }
    throw error;
  }
}

client.once("clientReady", () => {
  console.log(`Logged in as ${client.user.tag}.`);
  startPresenceRotation(client);
});

client.on("interactionCreate", async (interaction) => {
  if (interaction.isButton() && closeButtonIds.has(interaction.customId)) {
    const channel = interaction.channel;
    const ownerId = channel && getPrivateChatOwner(channel);
    if (!ownerId || ownerId !== interaction.user.id) {
      await interaction.reply({
        content: "Only the owner of this private chat can close it.",
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    if (interaction.customId === "close_private_chat") {
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("confirm_close_private_chat")
          .setLabel("Delete chat")
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId("cancel_close_private_chat")
          .setLabel("Cancel")
          .setStyle(ButtonStyle.Secondary),
      );
      await interaction.reply({
        content: "Are you sure? This permanently deletes this private chat.",
        components: [row],
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    if (interaction.customId === "cancel_close_private_chat") {
      await interaction.update({
        content: "Chat deletion canceled.",
        components: [],
      });
      return;
    }

    if (interaction.customId === "confirm_close_private_chat") {
      await interaction.update({
        content: "Deleting your private chat...",
        components: [],
      });
      try {
        await channel.delete(`Private chat closed by owner ${interaction.user.id}`);
      } catch (error) {
        console.error(`Could not close private chat ${channel.id}:`, error);
        await interaction.followUp({
          content: "I couldn't delete this chat. Check that I have Manage Channels permission.",
          flags: MessageFlags.Ephemeral,
        });
      }
    }
    return;
  }

  if (!interaction.isChatInputCommand() || interaction.commandName !== "createchat") {
    return;
  }

  if (interaction.channelId !== process.env.CHAT_COMMAND_CHANNEL_ID) {
    await interaction.reply({
      content: `Use /createchat in <#${process.env.CHAT_COMMAND_CHANNEL_ID}>.`,
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  try {
    const category = await interaction.guild.channels.fetch(
      process.env.CHAT_CATEGORY_ID,
    );
    if (!category || category.type !== ChannelType.GuildCategory) {
      throw new Error("CHAT_CATEGORY_ID must identify a category in this server.");
    }

    const privateChannel = await interaction.guild.channels.create({
      name: channelNameFor(
        interaction.member?.displayName ||
        interaction.member?.nick ||
        interaction.user.globalName ||
        interaction.user.username,
      ),
      type: ChannelType.GuildText,
      parent: category.id,
      topic: `private-ai-owner:${interaction.user.id}`,
      permissionOverwrites: [
        {
          id: interaction.guild.id,
          deny: [PermissionFlagsBits.ViewChannel],
        },
        {
          id: interaction.user.id,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.ReadMessageHistory,
          ],
        },
        {
          id: client.user.id,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.ReadMessageHistory,
          ],
        },
      ],
    });

    await interaction.editReply(
      `Your private AI chat is ready: ${privateChannel}`,
    );
    const closeRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("close_private_chat")
        .setLabel("Close chat")
        .setStyle(ButtonStyle.Danger),
    );
    await privateChannel.send({
      content: `Hi <@${interaction.user.id}>! This channel is private to you and the bot. Send a message here to chat with AI. Use the button below to close it.`,
      components: [closeRow],
      allowedMentions: { parse: [] },
    });
  } catch (error) {
    console.error("Could not create a private AI channel:", error);
    await interaction.editReply(
      "I couldn't create your chat. Check that the category ID is correct and that the bot can manage channels.",
    );
  }
});

client.on("messageCreate", async (message) => {
  if (message.author.bot || !message.guild) {
    return;
  }

  const ownerId = getPrivateChatOwner(message.channel);
  if (ownerId !== message.author.id) {
    return;
  }

  if (!message.content.trim()) {
    console.warn(
      `Received an empty message in private AI channel ${message.channel.id}. ` +
      "Check that Message Content Intent is enabled in the Discord Developer Portal.",
    );
    await message.channel.send({
      content:
        "I received your message but couldn't read its text. Please enable Message Content Intent for the bot in the Discord Developer Portal, restart me, and try again.",
      allowedMentions: { parse: [] },
    });
    return;
  }

  const channelId = message.channel.id;
  console.info(`Received an AI chat message in channel ${channelId}.`);
  const previous = channelQueues.get(channelId) || Promise.resolve();
  const current = previous
    .catch(() => {})
    .then(async () => {
      try {
        await message.channel.sendTyping();
      } catch (error) {
        console.warn(`Could not show typing indicator in channel ${channelId}:`, error);
      }
      await handlePrivateChatMessage(message);
    })
    .catch(async (error) => {
      console.error(`AI reply failed in channel ${channelId}:`, error);
    });

  channelQueues.set(channelId, current);
  try {
    await current;
  } finally {
    if (channelQueues.get(channelId) === current) {
      channelQueues.delete(channelId);
    }
  }
});

client.on("channelDelete", (channel) => {
  conversations.delete(channel.id);
  channelQueues.delete(channel.id);
});

client.login(process.env.DISCORD_TOKEN);
