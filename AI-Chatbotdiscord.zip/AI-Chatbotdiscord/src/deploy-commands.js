require("dotenv").config();

const { REST, Routes, SlashCommandBuilder } = require("discord.js");

const requiredVariables = [
  "DISCORD_TOKEN",
  "DISCORD_CLIENT_ID",
  "DISCORD_GUILD_ID",
];
const missingVariables = requiredVariables.filter(
  (name) => !process.env[name],
);

if (missingVariables.length > 0) {
  throw new Error(`Missing required environment variables: ${missingVariables.join(", ")}`);
}

const commands = [
  new SlashCommandBuilder()
    .setName("createchat")
    .setDescription("Create a private AI chat channel for yourself.")
    .toJSON(),
];

const rest = new REST({ version: "10" }).setToken(process.env.DISCORD_TOKEN);

rest
  .put(
    Routes.applicationGuildCommands(
      process.env.DISCORD_CLIENT_ID,
      process.env.DISCORD_GUILD_ID,
    ),
    { body: commands },
  )
  .then(() => {
    console.log("Registered /createchat for the configured Discord server.");
  })
  .catch((error) => {
    console.error("Failed to register Discord slash commands:", error);
    process.exitCode = 1;
  });
